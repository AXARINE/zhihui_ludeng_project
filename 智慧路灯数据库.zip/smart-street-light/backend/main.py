"""智慧路灯后端服务

功能：
- 账号管理：市政人员 / 路灯管理员 的增删查（密码 bcrypt 哈希）
- 数据采集：光照强度 / 心跳(设备状态) / 告警 上报接口（HTTP REST）
- 查询接口：供管理页面展示设备、告警、光照、角色

运行：  uvicorn main:app --host 127.0.0.1 --port 8000
文档：  http://127.0.0.1:8000/docs
管理页：http://127.0.0.1:8000/
"""
import os
from contextlib import contextmanager

import bcrypt
import pymysql
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

# ---------------- 数据库配置 ----------------
# 默认值适配团队共同开发环境（root/123456）。
# 队友的 MySQL 密码或地址不同时，无需改代码，用环境变量覆盖即可，例如：
#   set DB_PASSWORD=你的密码        (Windows cmd)
#   $env:DB_PASSWORD="你的密码"     (PowerShell)
DB_CONFIG = {
    "host": os.getenv("DB_HOST", "127.0.0.1"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "123456"),
    "database": os.getenv("DB_NAME", "smart_street_light"),
    "charset": "utf8mb4",
    "cursorclass": pymysql.cursors.DictCursor,
    "autocommit": True,
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

app = FastAPI(
    title="智慧路灯后端",
    description="智慧路灯平台接口：账号管理（市政人员 / 路灯管理员增删）与数据采集（光照 / 心跳 / 告警上报）。",
    version="1.0.0",
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@contextmanager
def get_conn():
    conn = pymysql.connect(**DB_CONFIG)
    try:
        yield conn
    finally:
        conn.close()


# ---------------- 密码哈希 ----------------
def hash_password(password: str) -> str:
    # bcrypt 只取前 72 字节
    return bcrypt.hashpw(password.encode("utf-8")[:72], bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8")[:72], hashed.encode("utf-8"))
    except ValueError:
        return False


# ---------------- 请求体模型 ----------------
class UserCreate(BaseModel):
    username: str = Field(..., min_length=1, max_length=64, description="登录用户名")
    password: str = Field(..., min_length=6, max_length=64, description="密码（至少 6 位）")
    real_name: str = Field("", max_length=64, description="姓名（可选）")
    role_id: int = Field(..., description="角色 ID：1 市政人员 / 2 路灯管理员")


class LuminanceIn(BaseModel):
    device_id: str = Field(..., min_length=1, max_length=64, description="设备唯一标识")
    luminance: float = Field(..., description="光照强度（lux）")


class HeartbeatIn(BaseModel):
    device_id: str = Field(..., min_length=1, max_length=64, description="设备唯一标识")
    online_status: bool = Field(..., description="在线状态：true 在线 / false 离线")


class AlarmIn(BaseModel):
    device_id: str = Field(..., min_length=1, max_length=64, description="设备唯一标识")
    alarm_type: str = Field("offline", max_length=32, description="告警类型，如 offline")
    message: str = Field("", max_length=255, description="告警内容")


class DeviceCreate(BaseModel):
    device_id: str = Field(..., min_length=1, max_length=64, description="设备唯一标识")
    name: str = Field("", max_length=128, description="设备名称")
    location: str = Field("", max_length=255, description="安装位置/路段")


def _ensure_device(conn, device_id: str):
    """上报数据时若设备不存在则自动注册"""
    with conn.cursor() as cur:
        cur.execute("SELECT id FROM device WHERE device_id=%s", (device_id,))
        if cur.fetchone() is None:
            cur.execute(
                "INSERT INTO device (device_id, name, location, online_status, last_heartbeat) "
                "VALUES (%s, %s, '', 0, NULL)",
                (device_id, device_id),
            )


# ---------------- 健康检查 / 角色 ----------------
@app.get("/api/health", summary="健康检查", tags=["系统"])
def health():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1")
            cur.fetchone()
    return {"status": "ok", "database": "connected"}


@app.get("/api/roles", summary="角色列表", tags=["账号管理"])
def list_roles():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id, role_code, role_name, description FROM role ORDER BY id")
            return cur.fetchall()


# ---------------- 用户增删查 ----------------
@app.get("/api/users", summary="账号列表", tags=["账号管理"])
def list_users():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT u.id, u.username, u.real_name, u.role_id,
                       r.role_code, r.role_name, u.status, u.created_at
                FROM user u JOIN role r ON r.id = u.role_id
                ORDER BY u.id
                """
            )
            return cur.fetchall()


@app.post("/api/users", status_code=201, summary="新增账号", tags=["账号管理"])
def create_user(body: UserCreate):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM role WHERE id=%s", (body.role_id,))
            if cur.fetchone() is None:
                raise HTTPException(status_code=400, detail="角色不存在")
            cur.execute("SELECT id FROM user WHERE username=%s", (body.username,))
            if cur.fetchone() is not None:
                raise HTTPException(status_code=409, detail="用户名已存在")
            cur.execute(
                "INSERT INTO user (username, password_hash, real_name, role_id, status) "
                "VALUES (%s, %s, %s, %s, 1)",
                (body.username, hash_password(body.password), body.real_name, body.role_id),
            )
            new_id = cur.lastrowid
    return {"id": new_id, "username": body.username, "role_id": body.role_id}


@app.delete("/api/users/{user_id}", summary="删除账号", tags=["账号管理"])
def delete_user(user_id: int):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM user WHERE id=%s", (user_id,))
            if cur.fetchone() is None:
                raise HTTPException(status_code=404, detail="用户不存在")
            cur.execute("DELETE FROM user WHERE id=%s", (user_id,))
    return {"deleted": user_id}


# ---------------- 数据采集接口 ----------------
@app.post("/api/data/luminance", status_code=201, summary="上报光照强度", tags=["数据采集"])
def report_luminance(body: LuminanceIn):
    with get_conn() as conn:
        _ensure_device(conn, body.device_id)
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO luminance_data (device_id, luminance) VALUES (%s, %s)",
                (body.device_id, body.luminance),
            )
            new_id = cur.lastrowid
            cur.execute(
                "SELECT id, device_id, luminance, created_at FROM luminance_data WHERE id=%s",
                (new_id,),
            )
            row = cur.fetchone()
    return row


@app.post("/api/data/heartbeat", summary="上报设备心跳/状态", tags=["数据采集"])
def report_heartbeat(body: HeartbeatIn):
    with get_conn() as conn:
        _ensure_device(conn, body.device_id)
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE device SET online_status=%s, last_heartbeat=NOW() WHERE device_id=%s",
                (1 if body.online_status else 0, body.device_id),
            )
            cur.execute(
                "SELECT id, device_id, online_status, last_heartbeat FROM device WHERE device_id=%s",
                (body.device_id,),
            )
            row = cur.fetchone()
    return row


@app.post("/api/data/alarm", status_code=201, summary="上报设备告警", tags=["数据采集"])
def report_alarm(body: AlarmIn):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO alarm_record (device_id, alarm_type, message, status) "
                "VALUES (%s, %s, %s, 0)",
                (body.device_id, body.alarm_type, body.message),
            )
            new_id = cur.lastrowid
            cur.execute(
                "SELECT id, device_id, alarm_type, message, status, created_at "
                "FROM alarm_record WHERE id=%s",
                (new_id,),
            )
            row = cur.fetchone()
    return row


# ---------------- 设备管理（增删查） ----------------
@app.post("/api/devices", status_code=201, summary="新增路灯设备", tags=["设备管理"])
def create_device(body: DeviceCreate):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id FROM device WHERE device_id=%s", (body.device_id,))
            if cur.fetchone() is not None:
                raise HTTPException(status_code=409, detail="设备ID已存在")
            cur.execute(
                "INSERT INTO device (device_id, name, location, online_status) VALUES (%s, %s, %s, 0)",
                (body.device_id, body.name, body.location),
            )
            new_id = cur.lastrowid
            cur.execute(
                "SELECT id, device_id, name, location, online_status, last_heartbeat, created_at "
                "FROM device WHERE id=%s",
                (new_id,),
            )
            row = cur.fetchone()
    return row


@app.delete("/api/devices/{device_id}", summary="删除/解绑路灯设备", tags=["设备管理"])
def delete_device(device_id: int):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT id, device_id FROM device WHERE id=%s", (device_id,))
            row = cur.fetchone()
            if row is None:
                raise HTTPException(status_code=404, detail="设备不存在")
            did = row["device_id"]
            # 级联清除该设备的关联数据
            cur.execute("DELETE FROM luminance_data WHERE device_id=%s", (did,))
            cur.execute("DELETE FROM threshold_config WHERE device_id=%s", (did,))
            cur.execute("DELETE FROM alarm_record WHERE device_id=%s", (did,))
            cur.execute("DELETE FROM command_record WHERE device_id=%s", (did,))
            cur.execute("DELETE FROM device WHERE id=%s", (device_id,))
    return {"deleted": device_id, "device_id": did}


# ---------------- 查询接口（供管理页展示） ----------------
@app.get("/api/devices", summary="设备列表", tags=["设备管理"])
def list_devices():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT id, device_id, name, location, online_status, last_heartbeat, created_at "
                "FROM device ORDER BY id DESC"
            )
            return cur.fetchall()


@app.get("/api/alarms", summary="告警列表", tags=["查询"])
def list_alarms(limit: int = 50):
    limit = max(1, min(int(limit), 1000))
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"SELECT id, device_id, alarm_type, message, status, created_at "
                f"FROM alarm_record ORDER BY id DESC LIMIT {limit}"
            )
            return cur.fetchall()


@app.get("/api/luminance", summary="光照数据", tags=["查询"])
def list_luminance(device_id: str | None = None, limit: int = 50):
    limit = max(1, min(int(limit), 1000))
    with get_conn() as conn:
        with conn.cursor() as cur:
            if device_id:
                cur.execute(
                    f"SELECT id, device_id, luminance, created_at FROM luminance_data "
                    f"WHERE device_id=%s ORDER BY id DESC LIMIT {limit}",
                    (device_id,),
                )
            else:
                cur.execute(
                    f"SELECT id, device_id, luminance, created_at FROM luminance_data "
                    f"ORDER BY id DESC LIMIT {limit}"
                )
            return cur.fetchall()


# ---------------- 静态页面 ----------------
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))
